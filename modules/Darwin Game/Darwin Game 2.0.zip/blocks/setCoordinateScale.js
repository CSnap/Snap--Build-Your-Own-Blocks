(function () {
   return function (num) {
      coordinateScale = num
   };
}());
