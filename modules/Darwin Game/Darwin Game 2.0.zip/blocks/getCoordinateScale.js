(function () {
   return function () {
      return coordinateScale
   };
}());
