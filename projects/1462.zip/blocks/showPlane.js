(function () {
    return function () {
        this.addCoordinatePlane();
    };
}());


 //# sourceURL=showPlane.js