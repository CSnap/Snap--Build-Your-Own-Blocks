(function () {
    return function () {
        return this._3DRotationY;
    };
}());


 //# sourceURL=3DRotationY.js