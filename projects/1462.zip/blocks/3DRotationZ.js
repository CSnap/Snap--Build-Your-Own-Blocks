(function () {
    return function () {
        return this._3DRotationZ;
    };
}());


 //# sourceURL=3DRotationZ.js